<?php
$servername = "localhost";
$username = "root";
$password = "";
$databasename = "cafebistro_phpoo_turmaB";

//CRIAÇÃO DE CONEXÃO
$conn = new mysqli($servername, $username, $password, $databasename);

//VERIFICANDO A  CONEXÃO
if (!$conn){
    //DIE ("CONEXÃO FALHOU".MYSQLI_CONNECT_ERROR());
    echo "não foi possível conetar ao banco de dados";
}else{
    echo "conectou";
};
?>