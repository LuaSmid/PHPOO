<?php
session_start();

// Verifique se os dados foram recebidos via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtém os dados enviados
    $usuario = $_POST['usuario'];
    $nomeusuario = $_POST['nomeusuario'];
    $id = $_POST['id'];
    $nomeProduto = $_POST['nomeP'];
    $preco = $_POST['preco'];

    // Faz alguma coisa com os dados recebidos, se necessário
    // ...

    // Configura as variáveis de sessão, se necessário
    $_SESSION['usuario'] = $usuario;
    $_SESSION['nomeusuario'] = $nomeusuario;

    // Agora, você pode atualizar o produto usando os dados fornecidos
    // Certifique-se de incluir os arquivos necessários e criar uma instância do seu repositório
    include '..\controladora\conexao.php';
    include '..\Modelo\Produto.php';
    include '..\Repositorio\ProdutoRepositorio.php';

    $produtosRepositorio = new ProdutoRepositorio($conn);

    // Obtenha o produto do banco de dados usando o ID
    $produto = $produtosRepositorio->listarDonutsPorId($id);

    // Atualize as propriedades do produto
    $produto->setNome($nomeProduto);
    $produto->setPreco($preco);

    // Agora, você pode chamar a função de atualização no seu repositório
    $atualizacaoSucesso = $produtosRepositorio->atualizarProduto($produto);

    if ($atualizacaoSucesso) {
        // Redirecione para a página de sucesso
        header("Location: editar-produto-sucesso.php");
        exit;
    } else {
        echo "Erro ao atualizar o produto.";
        exit;
    }
} else {
    echo "Requisição inválida.";
    exit;
}


require '../visao/menu.php';
require_once "conexao.php";
require '../Repositorio/ProdutoRepositorio.php';
require '../Modelo/Produto.php';
// ...

//$codigo = rand(0, 100000);
$produtosRepositorio = new ProdutoRepositorio($conn);

if (isset($_POST['editar'])){
  $produto = new Produto($_POST['id'], $_POST['nomeP'], $_POST['preco']);


    //se a imagem foi carregada
    if (isset($_FILES['imagem']['name']) && ($_FILES['imagem']['error'] == 0)){
        $testeImagem = true;
        $produto->setImagem(uniqid() . $_FILES['imagem']['name']);
        move_uploaded_file($_FILES['imagem']['tmp_name'], $produto->getImagemDiretorio());
    }elseif ($_FILES['imagem']['error'] == UPLOAD_ERR_NO_FILE){
      $produto->setImagem('');
    }

  
    $imagem = $_FILES['imagem']['name'];
    $imagemError = $_FILES['imagem']['error'];
    
    $produtosRepositorio->atualizarProduto($produto);
  //  header("Location: ../visao/admin.php?codedit=$codigo");
    $nomeusuario = $_POST['nomeusuario'];
    $usuario = $_POST['usuario'];
    echo "<form id='redirectForm' action='../visao/admin.php?imagemNome={$imagem}&testeError={$imagemError}&teste={$teste}' method='POST'>";
    echo "<input type='hidden' name='id' value='{$_POST['id']}'>";
    echo "<input type='hidden' name='nomeP' value='{$_POST['nomeP']}'>";
    echo "<input type='hidden' name='nomeusuario' value='{$nomeusuario}'>";
    echo "<input type='hidden' name='usuario' value='{$usuario}'>";
    echo "<input type='hidden' name='preco' value='{$_POST['preco']}'>";
    echo "</form>";
    echo "<script>document.getElementById('redirectForm').submit();</script>";



}
?>